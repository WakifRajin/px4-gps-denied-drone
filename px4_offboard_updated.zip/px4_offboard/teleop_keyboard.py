#!/usr/bin/env python3
import rclpy
import time
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy

import sys
import termios
import tty
import select

# Movement speeds
XY_VELOCITY = 0.8   # m/s for horizontal movement
YAW_RATE = 1.5      # rad/s for yaw rotation
CLIMB_RATE = 0.5    # m/s while W/S held. Release => altitude hold takes over
                     # in the controller node, no more hand-throttling.


class KeyboardTeleop(Node):
    def __init__(self):
        super().__init__('keyboard_teleop')

        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=5
        )

        self.pub = self.create_publisher(Twist, '/offboard_velocity_cmd', qos)
        self.arm_pub = self.create_publisher(Bool, '/arm_message', qos)

        self.armed = False

        # Track which movement keys are currently being "held"
        self.key_held_time = {}  # key -> last_time_seen
        self.key_timeout = 0.15  # If key not seen for 150ms, consider released

        self.get_logger().info("\n" + "=" * 50)
        self.get_logger().info("Keyboard Teleop Ready!")
        self.get_logger().info("=" * 50)
        self.get_logger().info("SPACE       = Arm / Disarm (auto climbs to hover alt & holds)")
        self.get_logger().info("W           = Climb (hold key)")
        self.get_logger().info("S           = Descend (hold key)")
        self.get_logger().info("Arrow UP    = Move Forward (hold key)")
        self.get_logger().info("Arrow DOWN  = Move Backward (hold key)")
        self.get_logger().info("Arrow LEFT  = Move Left (hold key)")
        self.get_logger().info("Arrow RIGHT = Move Right (hold key)")
        self.get_logger().info("A           = Yaw Left (hold key)")
        self.get_logger().info("D           = Yaw Right (hold key)")
        self.get_logger().info("Release any movement key -> that axis returns to 0 "
                                "(vertical axis: 0 means 'hold current altitude')")
        self.get_logger().info("=" * 50 + "\n")

        self.timer = self.create_timer(0.05, self.loop)  # 20 Hz

    def get_key(self):
        dr, _, _ = select.select([sys.stdin], [], [], 0)
        if dr:
            return sys.stdin.read(1)
        return None

    def loop(self):
        key = self.get_key()
        current_time = time.time()

        vx = 0.0
        vy = 0.0
        vz = 0.0
        yaw_rate = 0.0

        # Clean up old held keys
        expired = [k for k, t in self.key_held_time.items() if current_time - t > self.key_timeout]
        for k in expired:
            del self.key_held_time[k]

        if key is not None:
            if key == '\x03':  # CTRL+C
                raise KeyboardInterrupt()

            elif key == " ":
                self.armed = not self.armed
                msg = Bool()
                msg.data = self.armed
                self.arm_pub.publish(msg)
                status = "ARMED" if self.armed else "DISARMED"
                self.get_logger().info(f"*** {status} ***")

            elif key.lower() == 'w':
                self.key_held_time['w'] = current_time

            elif key.lower() == 's':
                self.key_held_time['s'] = current_time

            elif key.lower() == 'a':
                self.key_held_time['a'] = current_time

            elif key.lower() == 'd':
                self.key_held_time['d'] = current_time

            elif key == '\x1b':  # Arrow key prefix
                seq = sys.stdin.read(2)
                if seq == "[A":  # UP arrow
                    self.key_held_time['up'] = current_time
                elif seq == "[B":  # DOWN arrow
                    self.key_held_time['down'] = current_time
                elif seq == "[D":  # RIGHT arrow
                    self.key_held_time['right'] = current_time
                elif seq == "[C":  # LEFT arrow
                    self.key_held_time['left'] = current_time

        # Apply velocities for all currently held keys
        if 'a' in self.key_held_time:
            yaw_rate = -YAW_RATE
        if 'd' in self.key_held_time:
            yaw_rate = YAW_RATE
        if 'up' in self.key_held_time:
            vx = XY_VELOCITY
        if 'down' in self.key_held_time:
            vx = -XY_VELOCITY
        if 'left' in self.key_held_time:
            vy = XY_VELOCITY
        if 'right' in self.key_held_time:
            vy = -XY_VELOCITY
        if 'w' in self.key_held_time:
            vz = -CLIMB_RATE  # NED: negative z-velocity = climb
        if 's' in self.key_held_time:
            vz = CLIMB_RATE   # descend

        twist = Twist()
        twist.linear.x = vx
        twist.linear.y = vy
        twist.linear.z = vz
        twist.angular.z = yaw_rate
        self.pub.publish(twist)


def main(args=None):
    settings = termios.tcgetattr(sys.stdin)
    tty.setcbreak(sys.stdin.fileno())

    rclpy.init(args=args)
    node = KeyboardTeleop()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
