#!/usr/bin/env python3
"""
PX4 Offboard controller with:
  - simultaneous input from /cmd_vel (standard Twist, e.g. from an autonomy
    stack / joystick bridge / nav stack) AND /offboard_velocity_cmd
    (keyboard teleop) - whichever publishes last "wins", same as any normal
    cmd_vel consumer.
  - auto arm -> auto-takeoff-to-fixed-altitude -> altitude hold sequence, so
    you never have to hand-throttle to find hover. Space bar (via
    teleop_keyboard.py) arms; the drone climbs to HOVER_ALTITUDE_M on its own
    and holds it. From then on, vz commands from cmd_vel/teleop move the
    altitude up/down, and releasing the vertical axis re-engages the hold at
    whatever altitude you stopped at.
"""

import time
import math
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy

from px4_msgs.msg import (
    OffboardControlMode,
    TrajectorySetpoint,
    VehicleCommand,
    VehicleStatus,
    VehicleAttitude,
    VehicleLocalPosition,
)
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool

SETPOINT_RATE_HZ = 50.0
SETPOINT_WARMUP_COUNT = 30
INACTIVITY_TIMEOUT = 5.0  # seconds, hover-failsafe if no cmd_vel/teleop input

VEL_LIMIT_XY = 3.0
VEL_LIMIT_Z = 2.0
YAW_RATE_LIMIT = 2.0

# --- Auto takeoff / altitude hold ---
HOVER_ALTITUDE_M = 1.0          # target altitude after arming (meters, positive up)
TAKEOFF_CLIMB_VEL = 0.5         # m/s commanded climb rate during auto takeoff
ALTITUDE_REACHED_TOL = 0.10     # meters, switch TAKEOFF -> HOLD when within this band
ALT_HOLD_KP = 1.2               # P gain: m/s per meter of altitude error
ALT_HOLD_MAX_VEL = 0.8          # m/s clamp on the altitude-hold correction
Z_CMD_DEADZONE = 0.05           # m/s; |vz command| below this counts as "no vertical input"

# State machine
STATE_DISARMED = 'DISARMED'
STATE_TAKEOFF = 'TAKEOFF'
STATE_HOLD = 'HOLD'


class PX4Offboard(Node):
    def __init__(self):
        super().__init__('px4_offboard_control')

        # Tunable via `ros2 run ... --ros-args -p hover_altitude:=1.5` etc.
        self.declare_parameter('hover_altitude', HOVER_ALTITUDE_M)
        self.declare_parameter('takeoff_climb_vel', TAKEOFF_CLIMB_VEL)
        self.hover_altitude = self.get_parameter('hover_altitude').value
        self.takeoff_climb_vel = self.get_parameter('takeoff_climb_vel').value

        qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=5
        )

        # Publishers
        self.ctrl_mode_pub = self.create_publisher(OffboardControlMode, '/fmu/in/offboard_control_mode', qos)
        self.setpoint_pub = self.create_publisher(TrajectorySetpoint, '/fmu/in/trajectory_setpoint', qos)
        self.cmd_pub = self.create_publisher(VehicleCommand, '/fmu/in/vehicle_command', qos)

        # Subscribers - BOTH cmd_vel sources feed the same callback, so
        # whichever one is actively publishing drives the drone. This is the
        # "merge" of the two nodes' inputs: no need to run two separate
        # controllers, and you can switch between keyboard and an autonomy
        # node's /cmd_vel output without restarting anything.
        self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_cb, qos)
        self.create_subscription(Twist, '/offboard_velocity_cmd', self.teleop_cb, qos)
        self.create_subscription(Bool, '/arm_message', self.arm_cb, qos)
        self.create_subscription(VehicleStatus, '/fmu/out/vehicle_status_v1', self.status_cb, qos)
        self.create_subscription(VehicleAttitude, '/fmu/out/vehicle_attitude', self.att_cb, qos)
        self.create_subscription(VehicleLocalPosition, '/fmu/out/vehicle_local_position_v1',
                                  self.local_pos_cb, qos)

        # Commanded velocities (body/FLU frame, from whichever source last published)
        self.vx = self.vy = self.vz = self.yawspeed = 0.0

        self.yaw = 0.0
        self.status = VehicleStatus()
        self.local_pos = VehicleLocalPosition()
        self.have_local_pos = False

        self.armed = False
        self.warmed_up = False
        self.state = STATE_DISARMED

        # Altitude the HOLD state is currently trying to maintain (NED z, meters)
        self.hold_target_z = None
        self.takeoff_target_z = None

        self.last_cmd_time = time.time()

        self.create_timer(1.0 / SETPOINT_RATE_HZ, self.loop)
        self.get_logger().info(
            f"PX4 Offboard control node initialized. hover_altitude={self.hover_altitude:.2f} m"
        )
        self.get_logger().info("Listening on BOTH /cmd_vel and /offboard_velocity_cmd (keyboard teleop).")

    # -------------------- State/telemetry callbacks --------------------
    def status_cb(self, msg):
        self.status = msg

    def att_cb(self, msg):
        q = msg.q
        if len(q) == 4:
            w, x, y, z = q
            self.yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))

    def local_pos_cb(self, msg):
        self.local_pos = msg
        self.have_local_pos = True

    # -------------------- Velocity command inputs --------------------
    def _apply_twist(self, msg: Twist):
        self.last_cmd_time = time.time()
        self.vx = max(-VEL_LIMIT_XY, min(VEL_LIMIT_XY, msg.linear.x))
        self.vy = max(-VEL_LIMIT_XY, min(VEL_LIMIT_XY, msg.linear.y))
        self.vz = max(-VEL_LIMIT_Z, min(VEL_LIMIT_Z, msg.linear.z))
        self.yawspeed = max(-YAW_RATE_LIMIT, min(YAW_RATE_LIMIT, msg.angular.z))

    def cmd_vel_cb(self, msg: Twist):
        """Standard /cmd_vel input (autonomy stack, joystick bridge, etc.)."""
        self._apply_twist(msg)

    def teleop_cb(self, msg: Twist):
        """Keyboard teleop input on /offboard_velocity_cmd."""
        self._apply_twist(msg)

    def arm_cb(self, msg: Bool):
        """External arm/disarm toggle (space bar in teleop_keyboard.py)."""
        if msg.data and not self.armed:
            self.get_logger().info("ARM command received")
            self.start_offboard()
            time.sleep(0.2)
            self.publish_cmd(VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM, param1=1.0)
            self.armed = True

            # Kick off auto takeoff-to-hover-altitude instead of handing the
            # user a bare hover(=throttle 0.5) they have to find by hand.
            base_z = self.local_pos.z if self.have_local_pos else 0.0
            self.takeoff_target_z = base_z - self.hover_altitude  # NED: up is negative z
            self.state = STATE_TAKEOFF
            self.get_logger().info(
                f"ARMED - auto-climbing to {self.hover_altitude:.2f} m and holding."
            )

        elif not msg.data and self.armed:
            self.get_logger().info("DISARM command received")
            self.publish_cmd(VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM, param1=0.0)
            self.armed = False
            self.warmed_up = False
            self.state = STATE_DISARMED
            self.hold_target_z = None
            self.takeoff_target_z = None
            self.vx = self.vy = self.vz = self.yawspeed = 0.0
            self.get_logger().info("DISARMED")

    # -------------------- Helpers --------------------
    def micros(self):
        return int(self.get_clock().now().nanoseconds / 1000)

    def publish_mode(self):
        msg = OffboardControlMode()
        msg.timestamp = self.micros()
        msg.position = False
        msg.velocity = True
        msg.acceleration = False
        msg.attitude = False
        msg.body_rate = False
        self.ctrl_mode_pub.publish(msg)

    def publish_setpoint(self, vx, vy, vz, yawspeed):
        msg = TrajectorySetpoint()
        msg.timestamp = self.micros()
        msg.position = [float('nan')] * 3
        msg.velocity = [vx, vy, vz]
        msg.acceleration = [float('nan')] * 3
        msg.jerk = [float('nan')] * 3
        msg.yaw = float('nan')
        msg.yawspeed = yawspeed
        self.setpoint_pub.publish(msg)

    def publish_cmd(self, cmd, **params):
        m = VehicleCommand()
        m.timestamp = self.micros()
        m.command = cmd
        m.target_system = 1
        m.target_component = 1
        m.source_system = 1
        m.source_component = 1
        m.from_external = True
        for k in ["param1", "param2", "param3", "param4", "param5", "param6", "param7"]:
            setattr(m, k, params.get(k, 0.0))
        self.cmd_pub.publish(m)

    # -------------------- Sequence control --------------------
    def start_offboard(self):
        if self.warmed_up:
            return
        self.get_logger().info("Warming up Offboard mode...")
        for _ in range(SETPOINT_WARMUP_COUNT):
            self.publish_mode()
            self.publish_setpoint(0.0, 0.0, 0.0, 0.0)
            time.sleep(1.0 / SETPOINT_RATE_HZ)

        self.get_logger().info("Requesting OFFBOARD mode...")
        self.publish_cmd(VehicleCommand.VEHICLE_CMD_DO_SET_MODE, param1=1.0, param2=6.0)
        self.warmed_up = True
        time.sleep(0.2)
        self.get_logger().info("Offboard mode ready!")

    # -------------------- Main loop --------------------
    def loop(self):
        now = time.time()
        self.publish_mode()

        if not self.armed or self.state == STATE_DISARMED:
            self.publish_setpoint(0.0, 0.0, 0.0, 0.0)
            return

        # Inactivity safety timeout - stop moving horizontally/yaw, but let
        # altitude hold keep doing its job below.
        inactive = (now - self.last_cmd_time) > INACTIVITY_TIMEOUT
        if inactive:
            self.vx = self.vy = self.yawspeed = 0.0
            self.vz = 0.0

        if self.state == STATE_TAKEOFF:
            self._run_takeoff()
            return

        # STATE_HOLD: horizontal + yaw pass straight through from
        # cmd_vel/teleop; vertical uses the commanded rate if the user is
        # actively pushing it, otherwise altitude-hold takes over.
        self._run_hold()

    def _run_takeoff(self):
        if not self.have_local_pos or self.takeoff_target_z is None:
            # No position feedback yet (e.g. estimator not ready) - climb
            # open-loop at a fixed rate rather than stalling forever.
            self.publish_setpoint(0.0, 0.0, -self.takeoff_climb_vel, 0.0)
            return

        current_z = self.local_pos.z
        error = self.takeoff_target_z - current_z  # negative error => need to climb

        if abs(error) <= ALTITUDE_REACHED_TOL:
            self.hold_target_z = current_z
            self.state = STATE_HOLD
            self.get_logger().info(
                f"Reached hover altitude ({-current_z:.2f} m). Holding - cmd_vel/teleop control enabled."
            )
            self.publish_setpoint(0.0, 0.0, 0.0, 0.0)
            return

        vz_cmd = self.takeoff_climb_vel if error < 0 else -self.takeoff_climb_vel
        self.publish_setpoint(0.0, 0.0, vz_cmd, 0.0)

    def _run_hold(self):
        # Rotate commanded body-frame (FLU) xy into world frame (NED)
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        wx = self.vx * cy - self.vy * sy
        wy = self.vx * sy + self.vy * cy

        if abs(self.vz) > Z_CMD_DEADZONE:
            # User is actively commanding a climb/descent - pass it through
            # and keep re-basing the hold altitude so that releasing the
            # stick/key holds wherever they stopped.
            wz = self.vz
            if self.have_local_pos:
                self.hold_target_z = self.local_pos.z
        elif self.have_local_pos and self.hold_target_z is not None:
            error = self.hold_target_z - self.local_pos.z
            wz = max(-ALT_HOLD_MAX_VEL, min(ALT_HOLD_MAX_VEL, ALT_HOLD_KP * error))
        else:
            wz = 0.0

        self.publish_setpoint(wx, wy, wz, self.yawspeed)

        if abs(self.yawspeed) > 0.01:
            self.get_logger().info(
                f"ROTATING: yaw_rate={self.yawspeed:.3f} rad/s | yaw={math.degrees(self.yaw):.1f}deg",
                throttle_duration_sec=0.3,
            )
        else:
            alt = -self.local_pos.z if self.have_local_pos else float('nan')
            self.get_logger().info(
                f"HOLD: vx={wx:.2f} vy={wy:.2f} vz={wz:.2f} alt={alt:.2f}m",
                throttle_duration_sec=0.5,
            )


def main(args=None):
    rclpy.init(args=args)
    node = PX4Offboard()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("PX4 Offboard control node shutting down...")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
