#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
import os


def generate_launch_description():

    # --- Configuration ---
    package_name = 'px4_offboard'
    ros_distro = 'jazzy'
    hover_altitude = '1.0'   # meters, passed to the controller as a ROS param
    # ---------------------

    ros_setup_path = f'/opt/ros/{ros_distro}/setup.bash'

    # Controller node: auto arm->takeoff->hold, listens on BOTH /cmd_vel and
    # /offboard_velocity_cmd (keyboard teleop) simultaneously.
    controller_node = Node(
        package=package_name,
        executable='cmd_vel_offboard_control.py',
        name='cmd_vel_offboard_control',
        output='screen',
        emulate_tty=True,
        parameters=[{'hover_altitude': float(hover_altitude)}],
    )

    # Keyboard teleop in its own terminal (needs raw stdin, can't share a
    # process with the real-time control loop above)
    teleop_node_process = ExecuteProcess(
        cmd=[
            'gnome-terminal',
            '--',
            'bash', '-c',
            f'source {ros_setup_path} && '
            f'echo "Terminal for Keyboard Teleop (Press Space to Arm)" && '
            f'ros2 run {package_name} teleop_keyboard.py; '
            'exec bash'
        ],
        output='screen',
        shell=False
    )

    return LaunchDescription([
        controller_node,
        teleop_node_process
    ])
